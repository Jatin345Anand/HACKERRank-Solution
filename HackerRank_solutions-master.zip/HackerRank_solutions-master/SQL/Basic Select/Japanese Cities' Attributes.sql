--     Author: Rodney Shaghoulian
--     Github: github.com/RodneyShag
-- HackerRank: hackerrank.com/RodneyShag

SELECT * FROM CITY
WHERE COUNTRYCODE = 'JPN';
