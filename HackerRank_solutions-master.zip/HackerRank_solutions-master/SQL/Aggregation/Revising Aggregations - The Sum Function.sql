--     Author: Rodney Shaghoulian
--     Github: github.com/RodneyShag
-- HackerRank: hackerrank.com/RodneyShag

SELECT SUM(POPULATION) FROM CITY
WHERE DISTRICT = 'California';
