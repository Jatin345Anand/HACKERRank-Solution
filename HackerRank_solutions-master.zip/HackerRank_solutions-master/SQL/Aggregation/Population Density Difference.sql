--     Author: Rodney Shaghoulian
--     Github: github.com/RodneyShag
-- HackerRank: hackerrank.com/RodneyShag

SELECT MAX(POPULATION) - MIN(POPULATION)
FROM CITY;
