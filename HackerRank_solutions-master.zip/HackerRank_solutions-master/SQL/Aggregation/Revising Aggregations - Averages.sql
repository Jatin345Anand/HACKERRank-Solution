--     Author: Rodney Shaghoulian
--     Github: github.com/RodneyShag
-- HackerRank: hackerrank.com/RodneyShag

SELECT AVG(POPULATION) FROM CITY
WHERE DISTRICT = 'California';
