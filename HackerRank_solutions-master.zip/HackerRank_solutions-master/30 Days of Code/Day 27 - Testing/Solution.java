//     Author: Rodney Shaghoulian
//     Github: github.com/RodneyShag
// HackerRank: hackerrank.com/RodneyShag

public class Solution {
    public static void main(String[] args) {
        System.out.println(5);

        System.out.println("4 3");
        System.out.println("-1 0 1 2");
        
        System.out.println("3 1");
        System.out.println("-1 0 1");
        
        System.out.println("5 4");
        System.out.println("-1 0 1 2 3");
        
        System.out.println("6 1");
        System.out.println("-1 0 1 2 3 4");
        
        System.out.println("7 6");
        System.out.println("-1 0 1 2 3 4 5");
    }
}
